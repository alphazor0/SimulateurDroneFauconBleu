# Minecraft
Voxel Engine (like Minecraft) in Python and OpenGL 

Control: ZQSD shift space + mouse

![minecraft](/screenshot/0.jpg)
